<?php
// Prevent direct access to file
defined('shoppingcart') or exit;
// your php code here
?>
<?=template_header('Page Title')?>

<div class="content-wrapper">

    <h2>Page Title</h2>

    <div>
        your content here test
        <a href="index.php?page=myaccount"> login</a>
    </div>

</div>

<?=template_footer()?>