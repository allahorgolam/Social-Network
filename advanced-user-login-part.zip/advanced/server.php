<?php


// initializing variables
$username = "";
$email    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'shoppingcart_advanced');

// REGISTER USER
if (isset($_POST['reg_user'])) {
  // receive all input values from the form
    $phone_number = mysqli_real_escape_string($db, $_POST['phone_number']);
    $my_name = mysqli_real_escape_string($db, $_POST['my_name']);
    $dokan_name = mysqli_real_escape_string($db, $_POST['dokan_name']);
    $dokan_location = mysqli_real_escape_string($db, $_POST['dokan_location']);
    $comment = mysqli_real_escape_string($db, $_POST['comment']);

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($phone_number)) { array_push($errors, "phone_number is required"); }
  if (empty($my_name)) { array_push($errors, "my_name is required"); }
  if (empty($dokan_name)) { array_push($errors, "Username is required"); }
  if (empty($dokan_location)) { array_push($errors, "dokan_location is required"); }
  if (empty($comment)) { array_push($errors, "comment is required"); }

  $query = "INSERT INTO request (phone_number, my_name,dokan_name,dokan_location,comment)
     VALUES ('$phone_number', '$my_name', '$dokan_name', '$dokan_location','$comment')";
  	mysqli_query($db, $query);
  }

  
  
