<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Grameen Commerce</title>
    <link rel="shortcut icon" href="favicon.png">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="m-4">
  <h1 style="text-align: center;">আপনার তথ্য প্রদান করুন </h1>
    <form method="post" action="request.php">
    <?php include('errors.php'); ?>
        <div class="mb-3">
            <label class="form-label" for="inputPassword">নাম</label>
            <input class="form-control" type="text" name="my_name" value="" placeholder="উদহারণ :মো: আরিফ / Md Arif" value="<?php echo $my_name; ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label" for="inputEmail">মোবাইল নম্বর </label>
            <input type="tel" class="form-control"  id="phone" name="phone_number"  placeholder="উদহারণ : 01785699069" required>
        </div>
    
              <div class="mb-3">
            <label class="form-label" for="inputPassword">দোকানের নাম</label>
            <input class="form-control" name="dokan_name" value="" placeholder="উদহারণ : আরিফ স্টোর / Arif Store " value="<?php echo $dokan_name; ?>" required>
        </div>
                <div class="mb-3">
            <label class="form-label" for="inputPassword">দোকানের লোকেশন</label>
            <input class="form-control" type="text" name="dokan_location" value="" placeholder="উদহারণ : পাট্টা বাজার ,পাংশা ,রাজবাড়ী / Patta,Jona.Pangsha,Rajbari" value="<?php echo $dokan_location; ?>" required>
        </div>
        <button type="submit" name="reg_user" class="btn btn-primary">Register</button>
          <br>
          <br>
              <p >
        আগে থেকেই কি  একাউন্ট খুলা  আছে ? তাহলে এই  <span style="color:green; font-weight: bold;"><a  class="btn btn-primary" href="index.php?page=myaccount" title="">Login</a></span> বাটন এ ক্লিক করুন 
    </p>

    </form>
</div>
</body>
</html>