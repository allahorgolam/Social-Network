
<?=template_header('')?>
<h1 style="text-align: center; margin-top: 150px;">২৪ ঘন্টার মধ্যে আমাদের একজন প্রতিনিধি আপনার সাথে যোগাযোগ করবে </h1>
<p style="text-align: center; margin-top: 30px;">হেল্প নাম্বার : 01307076639 <span>একাউন্ট খুলতে সমস্যা  হলে যোগাযোগ করুন  </span> </p>
 <h2 style="text-align: center; margin-top: 50px;"> <a href="index.php?page=home"> back  home page </a> </h2>
 <?=template_footer()?>