<?php


// initializing variables
$phone_number = "";
$my_name    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'grameen1_grameencommerce', 'B@laj1abena', 'grameen1_shoppingcart_advanced');

// REGISTER USER
if (isset($_POST['reg_user'])) {
  // receive all input values from the form
  $phone_number = mysqli_real_escape_string($db, $_POST['phone_number']);
  $my_name = mysqli_real_escape_string($db, $_POST['my_name']);
  $dokan_name = mysqli_real_escape_string($db, $_POST['dokan_name']);
  $dokan_location = mysqli_real_escape_string($db, $_POST['dokan_location']);
 
  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($phone_number)) { array_push($errors, "phone_number is required"); }
  if (empty($my_name)) { array_push($errors, "my_name is required"); }
  if (empty($dokan_name)) { array_push($errors, "dokan_name is required"); }
  if (empty($dokan_location)) { array_push($errors, "dokan_location is required"); }


  // first check the database to make sure 
  // a user does not already exist with the same phone_number and/or my_name
  $user_check_query = "SELECT * FROM  request WHERE phone_number='$phone_number' OR my_name='$my_name' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['phone_number'] === $phone_number) {
      array_push($errors, "phone_number already exists");
    }

    
  }

  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
    $password = md5($password_1);//encrypt the password before saving in the database

    $query = "INSERT INTO  request (phone_number, my_name,dokan_name,dokan_location) 
          VALUES('$phone_number', '$my_name','$dokan_name','$dokan_location')";
    mysqli_query($db, $query);
    $_SESSION['phone_number'] = $phone_number;
    $_SESSION['success'] = "You are now logged in";
    header('location: index.php?page=pending');
  }
}

// ... 