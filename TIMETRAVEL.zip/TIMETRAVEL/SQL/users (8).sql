-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2019 at 02:12 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `social_network`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `f_name` text NOT NULL,
  `l_name` text NOT NULL,
  `user_name` text NOT NULL,
  `describe_user` varchar(255) NOT NULL,
  `Relationship` text NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_country` text NOT NULL,
  `user_gender` text NOT NULL,
  `user_birthday` text NOT NULL,
  `user_image` varchar(255) NOT NULL,
  `user_cover` varchar(255) NOT NULL,
  `user_reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` text NOT NULL DEFAULT current_timestamp(),
  `posts` text NOT NULL,
  `recovery_account` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `f_name`, `l_name`, `user_name`, `describe_user`, `Relationship`, `user_pass`, `user_email`, `user_country`, `user_gender`, `user_birthday`, `user_image`, `user_cover`, `user_reg_date`, `status`, `posts`, `recovery_account`) VALUES
(5, 'hafez', 'mahmud', 'hafez_mahmud_17323', 'Hello Coding Cafe.This is my default status!', '', 'ALLAHUAKBAR', 'mdmahmudor@gmail.com', 'UAE', '', '2019-11-05', 'm.JPG.26', 'digital-crime-by-anonymous-hacker-450w-1095422036 (1).jpg.47', '2019-11-18 00:53:47', 'verified', 'yes', 'ALLAH'),
(6, 'farzana', 'moon', 'farzana_moon_311978', 'Hello Coding Cafe.This is my default status!', '...', 'bolajabena', 'nobijirbondhu@gmail.com', 'Pakistan', 'Female', '2019-11-15', '68636739_2335348093447852_7262126155153539072_o (2).jpg.51', 'pexels-photo-247878.jpg.36', '2019-11-17 02:18:42', 'verified', 'yes', 'uuuuuuuuuuu'),
(7, 'sinha', 'mim', 'sinha_mim_144957', 'Hello Coding Cafe.This is my default status!', '...', 'hafezmahmud9', 'mdmahmudor@gmail.com', 'Pakistan', 'Female', '2019-11-07', 'head_turqoise.png', 'default_cover.jpg', '2019-11-16 05:23:47', 'verified', 'no', 'Iwanttoputading intheuniverse.'),
(8, 'sila', 'mahmud', 'sila_mahmud_399775', 'Hello Coding Cafe.This is my default status!', '...', '123456789', 'mdmahmudor2@gmail.com', 'Pakistan', 'Male', '2019-11-16', '56890293_635899843547526_5480637694310612992_n.jpg.4', 'default_cover.jpg', '2019-11-16 08:06:56', 'verified', 'no', 'Iwanttoputading intheuniverse.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
