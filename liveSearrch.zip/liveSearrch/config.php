<?php
$con = mysqli_connect("localhost","root","","live_search");

// Check conion
if (!$con) {
  echo "Failed to con to MySQL: " . mysqli_connect_error();
  exit();
}
?>