<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <style type="text/css" media="screen">
     <style type="text/css">
      * {
  margin: 0px;
  padding: 0px;
}
body {
  font-size: 120%;
  background: #F8F8FF;
}

.header {
  width: 30%;
  margin: 50px auto 0px;
  color: white;
  background: #5F9EA0;
  text-align: center;
  border: 1px solid #B0C4DE;
  border-bottom: none;
  border-radius: 10px 10px 0px 0px;
  padding: 20px;
}
form, .content {
  width: 30%;
  margin: 0px auto;
  padding: 20px;
  border: 1px solid #B0C4DE;
  background: white;
  border-radius: 0px 0px 10px 10px;
}
.input-group {
  margin: 10px 0px 10px 0px;
}
.input-group label {
  display: block;
  text-align: left;
  margin: 3px;
}
.input-group input {
  height: 30px;
  width: 93%;
  padding: 5px 10px;
  font-size: 16px;
  border-radius: 5px;
  border: 1px solid gray;
}
.btn {
  padding: 10px;
  font-size: 15px;
  color: white;
  background: #5F9EA0;
  border: none;
  border-radius: 5px;
}
.error {
  width: 92%; 
  margin: 0px auto; 
  padding: 10px; 
  border: 1px solid #a94442; 
  color: #a94442; 
  background: #f2dede; 
  border-radius: 5px; 
  text-align: left;
}
.success {
  color: #3c763d; 
  background: #dff0d8; 
  border: 1px solid #3c763d;
  margin-bottom: 20px;
}
  </style>
  </style>
</head>
<body>
  <div class="header">
    <h1 style="color:white">আপনার দোকানের তথ্য প্রদান করুন </h1>
  </div>
    <?php $_POST = array(); ?>
  <form method="post" action="request.php">
    <?php include('errors.php'); ?>
    <div class="input-group">
      <label> মোবাইল নম্বর </label>
      <input type="tel" id="phone" name="phone_number"  placeholder="উদহারণ : 01785699069" value="<?php echo $phone_number; ?>" >
    </div>
    <div class="input-group">
      <label>নাম </label>
      <input type="text" name="my_name" value="" placeholder="উদহারণ :মো: আরিফ / Md Arif" value="<?php echo $my_name; ?>" >
    </div>
    <div class="input-group">
      <label>দোকানের নাম</label>
      <input type="text" name="dokan_name" value="" placeholder="উদহারণ : আরিফ স্টোর / Arif Store " value="<?php echo $dokan_name; ?>" >
    </div>
    <div class="input-group">
      <label>দোকানের লোকেশন </label>
      <input type="text" name="dokan_location" value="" placeholder="উদহারণ : পাট্টা বাজার ,পাংশা ,রাজবাড়ী / Patta,Jona.Pangsha,Rajbari" value="<?php echo $dokan_location; ?>" >
    </div>
  <!--   <div class="input-group">
      <label>comment</label>
      <input type="text" name="comment" value="" placeholder="পাট্টা বাজার ,পাংশা ,রাজবাড়ী ">
    </div>
     -->
    <div class="input-group">
      <button type="submit" class="btn" name="reg_user" >Register</button>
    </div>
    <p>
        আগে থেকেই কি  একাউন্ট খুলা  আছে ? তাহলে নিচের <span style="color:green; font-weight: bold;">Login</span> বাটন এ ক্লিক করুন 
    </p>
    <div class="input-group">
      <button type="submit" class="btn" name="reg_user" ><a style="text-decoration:none;" href="index.php?page=myaccount">Login</a></button>
    </div>
    <br>
    <div>
      <p>হেল্প নাম্বার : 01307076639 <span>একাউন্ট খুলতে সমস্যা  হলে যোগাযোগ করুন  </span> </p>
    </div>
  </form>
  
</body>
</html>