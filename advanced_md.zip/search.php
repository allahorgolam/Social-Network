<?php
// Prevent direct access to file
defined('shoppingcart') or exit;
// Check for search query
if (isset($_GET['query']) && $_GET['query'] != '') {
    // Escape the user query, prevent XSS attacks
    $search_query = htmlspecialchars($_GET['query'], ENT_QUOTES, 'UTF-8');
    // Get the current category from the GET request, if none exists set the default selected category to: all
    $category = isset($_GET['category']) ? $_GET['category'] : 'all';
    $category_sql = '';
    if ($category != 'all') {
        $category_sql = 'JOIN products_categories pc ON pc.category_id = :category_id AND pc.product_id = p.id JOIN categories c ON c.id = pc.category_id';
    }
    $company_category = isset($_GET['company_category']) ? $_GET['company_category'] : 'all';
    $company_category_sql = '';
    if ($company_category != 'all') {
        $company_category_sql = 'JOIN products_categories2 pc2 ON pc2.category_id = :company_category_id AND pc2.product_id = p.id JOIN categories2 c2 ON c2.id = pc2.category_id';
    }
    $company_name = isset($_GET['company_name']) ? $_GET['company_name'] : 'all';
    $company_name_sql = '';
    if ($company_name != 'all') {
        $company_name_sql = 'p.company_name = :company_name AND ';
    }
    // Get the sort from GET request, will occur if the user changes an item in the select box
    $sort = isset($_GET['sort']) ? $_GET['sort'] : 'sort3';
    // The amounts of products to show on each page
    $num_products_on_each_page = 12;
    // The current page, in the URL this will appear as index.php?page=products&p=1, index.php?page=products&p=2, etc...
    $current_page = isset($_GET['p']) && is_numeric($_GET['p']) ? (int)$_GET['p'] : 1;
    $stmt = $pdo->prepare('SELECT p.* FROM products p WHERE p.status = 1 AND p.name LIKE ?');
    $stmt->execute([ '%' . $search_query . '%' ]);
    $og_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $company_names = array_filter(array_unique(array_column($og_products, 'company_name')));
    // Select products ordered by the date added
    if ($sort == 'sort1') {
        // sort1 = Alphabetical A-Z
        $stmt = $pdo->prepare('SELECT p.*, (SELECT m.full_path FROM products_media pm JOIN media m ON m.id = pm.media_id WHERE pm.product_id = p.id ORDER BY pm.position ASC LIMIT 1) AS img FROM products p ' . $category_sql . ' ' . $company_category_sql . ' WHERE ' . $company_name_sql . ' p.status = 1 AND p.name LIKE :search ORDER BY p.name ASC LIMIT :page,:num_products');
    } elseif ($sort == 'sort2') {
        // sort2 = Alphabetical Z-A
        $stmt = $pdo->prepare('SELECT p.*, (SELECT m.full_path FROM products_media pm JOIN media m ON m.id = pm.media_id WHERE pm.product_id = p.id ORDER BY pm.position ASC LIMIT 1) AS img FROM products p ' . $category_sql . ' ' . $company_category_sql . ' WHERE ' . $company_name_sql . ' p.status = 1 AND p.name LIKE :search ORDER BY p.name DESC LIMIT :page,:num_products');
    } elseif ($sort == 'sort3') {
        // sort3 = Newest
        $stmt = $pdo->prepare('SELECT p.*, (SELECT m.full_path FROM products_media pm JOIN media m ON m.id = pm.media_id WHERE pm.product_id = p.id ORDER BY pm.position ASC LIMIT 1) AS img FROM products p ' . $category_sql . ' ' . $company_category_sql . ' WHERE ' . $company_name_sql . ' p.status = 1 AND p.name LIKE :search ORDER BY p.date_added DESC LIMIT :page,:num_products');
    } elseif ($sort == 'sort4') {
        // sort4 = Oldest
        $stmt = $pdo->prepare('SELECT p.*, (SELECT m.full_path FROM products_media pm JOIN media m ON m.id = pm.media_id WHERE pm.product_id = p.id ORDER BY pm.position ASC LIMIT 1) AS img FROM products p ' . $category_sql . ' ' . $company_category_sql . ' WHERE ' . $company_name_sql . ' p.status = 1 AND p.name LIKE :search ORDER BY p.date_added ASC LIMIT :page,:num_products');
    } elseif ($sort == 'sort5') {
        // sort5 = Highest Price
        $stmt = $pdo->prepare('SELECT p.*, (SELECT m.full_path FROM products_media pm JOIN media m ON m.id = pm.media_id WHERE pm.product_id = p.id ORDER BY pm.position ASC LIMIT 1) AS img FROM products p ' . $category_sql . ' ' . $company_category_sql . ' WHERE ' . $company_name_sql . ' p.status = 1 AND p.name LIKE :search ORDER BY p.price DESC LIMIT :page,:num_products');
    } elseif ($sort == 'sort6') {
        // sort6 = Lowest Price
        $stmt = $pdo->prepare('SELECT p.*, (SELECT m.full_path FROM products_media pm JOIN media m ON m.id = pm.media_id WHERE pm.product_id = p.id ORDER BY pm.position ASC LIMIT 1) AS img FROM products p ' . $category_sql . ' ' . $company_category_sql . ' WHERE ' . $company_name_sql . ' p.status = 1 AND p.name LIKE :search ORDER BY p.price ASC LIMIT :page,:num_products');
    } else {
        // No sort was specified, get the products with no sorting
        $stmt = $pdo->prepare('SELECT p.*, (SELECT m.full_path FROM products_media pm JOIN media m ON m.id = pm.media_id WHERE pm.product_id = p.id ORDER BY pm.position ASC LIMIT 1) AS img FROM products p ' . $category_sql . ' ' . $company_category_sql . ' WHERE ' . $company_name_sql . ' p.status = 1 AND p.name LIKE :search LIMIT :page,:num_products');
    }
    // bindValue will allow us to use integer in the SQL statement, we need to use for LIMIT
    if ($category != 'all') {
        $stmt->bindValue(':category_id', $category, PDO::PARAM_INT);
    }
    if ($company_category != 'all') {
        $stmt->bindValue(':company_category_id', $company_category, PDO::PARAM_INT);
    }
    if ($company_name != 'all') {
        $stmt->bindValue(':company_name', $company_name, PDO::PARAM_STR);
    }
    $stmt->bindValue(':page', ($current_page - 1) * $num_products_on_each_page, PDO::PARAM_INT);
    $stmt->bindValue(':num_products', $num_products_on_each_page, PDO::PARAM_INT);
    $stmt->bindValue(':search', '%' . $search_query . '%', PDO::PARAM_STR);
    $stmt->execute();
    // Fetch the products from the database and return the result as an Array
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // Get the total number of products
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM products p ' . $category_sql . ' ' . $company_category_sql . ' WHERE  ' . $company_name_sql . ' p.status = 1 AND p.name LIKE :search');
    if ($category != 'all') {
        $stmt->bindValue(':category_id', $category, PDO::PARAM_INT);
    }
    if ($company_category != 'all') {
        $stmt->bindValue(':company_category_id', $company_category, PDO::PARAM_INT);
    }
    if ($company_name != 'all') {
        $stmt->bindValue(':company_name', $company_name, PDO::PARAM_STR);
    }
    $stmt->bindValue(':search', '%' . $search_query . '%', PDO::PARAM_STR);
    $stmt->execute();
    $total_products = $stmt->fetchColumn();
    // Get all the categories from the database
    $stmt = $pdo->prepare('SELECT c.* FROM categories c JOIN products_categories pc ON pc.category_id = c.id JOIN products p ON p.id = pc.product_id WHERE FIND_IN_SET(p.id, ?) GROUP BY name');
    $stmt->execute([ implode(',', array_column($og_products, 'id')) ]);
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare('SELECT c.* FROM categories2 c JOIN products_categories2 pc ON pc.category_id = c.id JOIN products p ON p.id = pc.product_id WHERE FIND_IN_SET(p.id, ?) GROUP BY name');
    $stmt->execute([ implode(',', array_column($og_products, 'id')) ]);
    $company_categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Simple error, if no search query was specified why is the user on this page?
    $error = 'No search query was specified!';
}
?>
<?=template_header('Search')?>

<?php if ($error): ?>

<p class="content-wrapper error"><?=$error?></p>

<?php else: ?>

<div class="products content-wrapper">

    <h1>Search Results for "<?=$search_query?>"</h1>

    <div class="products-header">
        <p><?=$total_products?> Product<?=$total_products!=1?'s':''?></p>
        <form action="" method="get" class="search-form">
            <input type="hidden" name="page" value="search">
            <input class="search-query" type="hidden" name="query" value="<?=$search_query?>">
            <!--
            <label class="company_name">
                Company Name
                <select name="company_name">
                    <option value="all"<?=($company_names == 'all' ? ' selected' : '')?>>All</option>
                    <?php foreach($company_names as $cn): ?>
                    <option value="<?=$cn?>"<?=($company_name == $cn ? ' selected' : '')?>><?=$cn?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            -->
            <label class="company_category">
                Company Category
                <select name="company_category">
                    <option value="all"<?=($company_category == 'all' ? ' selected' : '')?>>All</option>
                    <?=populate_categories($company_categories, $company_category)?>
                </select>
            </label>
            <label class="category">
                Category
                <select name="category">
                    <option value="all"<?=($category == 'all' ? ' selected' : '')?>>All</option>
                    <?=populate_categories($categories, $category)?>
                </select>
            </label>
            <label class="sortby">
                Sort by
                <select name="sort">
                    <option value="sort1"<?=($sort == 'sort1' ? ' selected' : '')?>>Alphabetical A-Z</option>
                    <option value="sort2"<?=($sort == 'sort2' ? ' selected' : '')?>>Alphabetical Z-A</option>
                    <option value="sort3"<?=($sort == 'sort3' ? ' selected' : '')?>>Newest</option>
                    <option value="sort4"<?=($sort == 'sort4' ? ' selected' : '')?>>Oldest</option>
                    <option value="sort5"<?=($sort == 'sort5' ? ' selected' : '')?>>Highest Price</option>
                    <option value="sort6"<?=($sort == 'sort6' ? ' selected' : '')?>>Lowest Price</option>
                </select>
            </label>
        </form>
    </div>

    <div class="products-wrapper">
        <?php foreach ($products as $product): ?>
        <a href="<?=url('index.php?page=product&id=' . ($product['url_slug'] ? $product['url_slug']  : $product['id']))?>" class="product">
            <?php if (!empty($product['img']) && file_exists($product['img'])): ?>
            <img src="<?=base_url?><?=$product['img']?>" width="200" height="200" alt="<?=$product['name']?>">
            <?php endif; ?>
            <span class="name"><?=$product['name']?></span>
            <span class="price">
                <?=currency_code?><?=number_format($product['price'],2)?>
                <?php if ($product['rrp'] > 0): ?>
                <span class="rrp"><?=currency_code?><?=number_format($product['rrp'],2)?></span>
                <?php endif; ?>
            </span>
        </a>
        <?php endforeach; ?>
    </div>

    <div class="buttons">
        <?php if ($current_page > 1): ?>
        <a href="<?=url('index.php?page=products&p=' . ($current_page-1) . '&category=' . $category . '&sort=' . $sort)?>" class="btn">Prev</a> 
        <?php endif; ?>
        <?php if ($total_products > ($current_page * $num_products_on_each_page) - $num_products_on_each_page + count($products)): ?>
        <a href="<?=url('index.php?page=products&p=' . ($current_page+1) . '&category=' . $category . '&sort=' . $sort)?>" class="btn">Next</a>
        <?php endif; ?>
    </div>

</div>

<?php endif; ?>

<?=template_footer()?>