<?php
// Prevent direct access to file
defined('shoppingcart') or exit;
// your php code here
?>
<?=template_header('Page Title')?>

<div class="content-wrapper">

    <h2>কোনো কিছু কিনতে হলে আগে আপনাকে লগইন করতে হবে </h2>

    <div>
     
        <h1> <a href="index.php?page=myaccount">  লগইন পেজে যান  login</a> </h1>
    </div>

    <h1> <a href="index.php?page=request">  যদি আপনার লগইন এর প্রবেশ না থাকে , তাহলে আমাদের অনুরোধ পেজে প্রবেশ করে আপনার ফরম টি পূরণ করুন </a> </h1>
   
    

</div>

<?=template_footer()?>