<?php
// Prevent direct access to file
defined('shoppingcart') or exit;
if (isset($_GET['query'])) {
    $stmt = $pdo->prepare('SELECT p.*, (SELECT m.full_path FROM products_media pm JOIN media m ON m.id = pm.media_id WHERE pm.product_id = p.id ORDER BY pm.position ASC LIMIT 1) AS img FROM products p WHERE p.status = 1 AND p.name LIKE ? ORDER BY p.date_added DESC');
    $stmt->execute(['%' . $_GET['query'] . '%']);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($products);
}
?>